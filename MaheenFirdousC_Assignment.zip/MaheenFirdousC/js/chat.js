function addMessage(text, sender) {
  let message = `<div class="message ${sender}">${text}</div>`;
  $("#messages").append(message);
  $("#messages").scrollTop($("#messages")[0].scrollHeight);
}

function getReply(input) {
  input = input.toLowerCase();

  if (input.includes("hello") || input.includes("hi")) {
    return "Hi how can I help you?";
  }
  else if (input.includes("who are you")) {
    return "I am your AI assistant";
  }
  else if (input.includes("how are you")) {
    return "I'm doing great!";
  }
  else if (input.includes("your name")) {
    return "I'm your Chat AI bot!";
  }
  else if (input.includes("bye")) {
    return "Goodbye! Have a great day!";
  }
  else if (input.includes("help")) {
    return "I can answer basic questions. Try asking me anything!";
  }
  else if (input.includes("what can you do")) {
    return "I can chat with you and answer simple questions";
  }
  else {
    return "That's interesting! Tell me more!";
  }
}

/* ✅ FIXED FUNCTION NAME */
function handelSend() {
  let input = $("#input").val().trim();

  if (input === "") return;

  addMessage(input, "user");
  $("#input").val("");

  $("#typing").removeClass("d-none");

  setTimeout(() => {
    $("#typing").addClass("d-none");

    let reply = getReply(input);
    addMessage(reply, "ai");

  }, 800);
}

/* ✅ FIXED EVENT CALLS */
$(document).ready(function () {
  $("#send").click(handelSend);

  $("#input").keydown(function(e) {
    if (e.key === "Enter") {
      e.preventDefault();
      handelSend();
    }
  });
});